/*
Copyright (C) 2015-2019 The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file LICENSE for details.
*/

#ifndef KEYBOARD_H
#define KEYBOARD_H

void keyboard_init();

#endif
