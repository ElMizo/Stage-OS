/*
Copyright (C) 2015-2019 The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file LICENSE for details.
*/

#include "ioports.h"
#include "kernel/types.h"
#include "console.h"

#define PIC_ICW1 0x11 //This is the initialization command word 1 for the PIC. 0x11 sets the PIC to operate in a specific mode.
#define PIC_ICW4_MASTER 0x01 // Initialization command word 4 for the master PIC. 0x01 sets the master PIC to operate in 8086/88 (MCS-80/85) mode.
#define PIC_ICW4_SLAVE  0x05 // Initialization command word 4 for the master PIC. 0x05 sets the slave PIC to operate in 8086/88 (MCS-80/85) mode.
#define PIC_ACK_SPECIFIC 0x60

static uint8_t pic_control[2] = { 0x20, 0xa0 }; //0x20 adrr for command master and 0xA0 for command slave
static uint8_t pic_data[2] = { 0x21, 0xa1 }; //0x21 adrr for data master and 0xA1 for data slave

/*This code initializes the Programmable Interrupt Controller (8259 PIC), 
which is responsible for handling hardware interrupts in x86-based systems. 
The PIC is typically composed of two chips, often referred to as the master (PIC0) and the slave (PIC1). 
The function pic_init sets up these two PICs.*/

void pic_init(int pic0base, int pic1base)
{   /*master set*/
    outb(PIC_ICW1, pic_control[0]); // Send ICW1 to master PIC command port
    outb(pic0base, pic_data[0]);    // Set base interrupt vector for master PIC
    outb(1 << 2, pic_data[0]);      // Tell master PIC about slave PIC at IRQ2
    outb(PIC_ICW4_MASTER, pic_data[0]); // Set master PIC to 8086 mode
    outb(~(1 << 2), pic_data[0]);   // Mask slave PIC's IRQ line on the master
	/*slave set*/
    outb(PIC_ICW1, pic_control[1]); // Send ICW1 to slave PIC command port
    outb(pic1base, pic_data[1]);    // Set base interrupt vector for slave PIC
    outb(2, pic_data[1]);           // Tell slave PIC its cascade identity
    outb(PIC_ICW4_SLAVE, pic_data[1]); // Set slave PIC to 8086 mode
    outb(~0, pic_data[1]);          // Mask all interrupts on the slave PIC

    printf("pic: ready\n");         // Print ready message
}

void pic_enable(uint8_t irq)
{
	uint8_t mask;
	if(irq < 8) {
		mask = inb(pic_data[0]);
		mask = mask & ~(1 << irq);
		outb(mask, pic_data[0]);
	} else {
		irq -= 8;
		mask = inb(pic_data[1]);
		mask = mask & ~(1 << irq);
		outb(mask, pic_data[1]);
		pic_enable(2);
	}
}

void pic_disable(uint8_t irq)
{
	uint8_t mask;
	if(irq < 8) {
		mask = inb(pic_data[0]);
		mask = mask | (1 << irq);
		outb(mask, pic_data[0]);
	} else {
		irq -= 8;
		mask = inb(pic_data[1]);
		mask = mask | (1 << irq);
		outb(mask, pic_data[1]);
	}
}

void pic_acknowledge(uint8_t irq)
{
	if(irq >= 8) {
		outb(PIC_ACK_SPECIFIC + (irq - 8), pic_control[1]); 
		outb(PIC_ACK_SPECIFIC + (2), pic_control[0]);
	} else {
		outb(PIC_ACK_SPECIFIC + irq, pic_control[0]);
	}
}
